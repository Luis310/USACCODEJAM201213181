public class adivinar {
    public static void main(String[] args) {
        int posicion1 = (int) (Math.random()*100+1);
        int valor=0;
        
        do{
             java.util.Scanner leer= new java.util.Scanner(System.in);
             valor= leer.nextInt();
           if (valor<posicion1) {
                System.out.println("El valor es menor que el numero");
            } else if (valor>posicion1) {
                    System.out.println("El valor es mayor que el numero");
                }
        }while(valor!=posicion1);        
System.out.println("Felicidades es el numero correcto");
    }
}