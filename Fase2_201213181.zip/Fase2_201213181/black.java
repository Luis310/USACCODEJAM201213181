public class black {
    public static void main(String[] args) {
        
        int carta1 = (int) (Math.random()*10+1);
        int carta2 = (int) (Math.random()*10+1);
        int cartaextra = (int) (Math.random()*10+1);
        int resultado1= carta1+carta2;
        int resultado2=carta1+carta2+cartaextra;
        System.out.println("[X] [x]");
        System.out.println("¿Desea su carta extra? y/n");
        java.util.Scanner l= new java.util.Scanner(System.in);
        String r;
        r=l.next();
        if ("y".equals(r)) {
            System.out.println(carta1+","+carta2+","+cartaextra+ "=" +resultado2);
        }else if ("n".equals(r)) {
            System.out.println(carta1+","+carta2+"="+resultado1);
        }
        if ((resultado1==21)||(resultado2==21)) {
            System.out.println("Felicidades");
        }else{
            System.out.println("Mejor suerte la proxima");
        }
    }
}