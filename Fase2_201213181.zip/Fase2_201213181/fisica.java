public class fisica {
    public static void main(String[] args) {
        
        double angulo=0;
        double velocidadinicial=0;
        
        velocidadinicial = Integer.parseInt(args[0].toString());
        angulo = Integer.parseInt(args[0].toString());
        
        double angradia=Math.toRadians(angulo);
        double Tvuelo= ((2*(velocidadinicial)*(Math.sin(angradia)))/(9.8));
        double Dmax= ((Math.pow(velocidadinicial,2)*(Math.sinh(2*(angradia))))/(9.8));
        
        System.out.println("Se matiene en el aire "+Tvuelo+ "segundos" );
        System.out.println("Avanza "+ Dmax+" metros ");
    }
}